<div>
    {!! $body !!}
</div>