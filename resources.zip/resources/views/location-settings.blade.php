<x-app-layout>
    <h1 class="text-2xl font-bold mb-4">Location Settings</h1>
    @livewire('location-manager')
</x-app-layout>
