<x-minimal>
    <div class="md:px-20">
        <livewire:graph.pest-rain-comparison />
    </div>
</x-minimal>
