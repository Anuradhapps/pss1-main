<x-minimal>
    <div class="md:px-20">
        <livewire:graph.pest-temp-comparison-chart />
    </div>
</x-minimal>
