<x-minimal>
    <div class="md:px-20">
        @livewire('graph.chart')
        {{-- <livewire:graph.pest-season-comparison-chart /> --}}
    </div>
</x-minimal>
