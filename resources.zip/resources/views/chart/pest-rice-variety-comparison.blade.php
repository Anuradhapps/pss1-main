<x-minimal>
    <div class="md:px-20">

        <livewire:graph.pest-other-comparison />

    </div>
</x-minimal>
